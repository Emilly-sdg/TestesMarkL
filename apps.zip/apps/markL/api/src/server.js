"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var app_1 = require("./app");
app_1.app.listen(3333, function () { return console.log("Server is running!"); });
